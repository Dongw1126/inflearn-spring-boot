package bccard.payzintern;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PayzInternApplication {

	public static void main(String[] args) {
		SpringApplication.run(PayzInternApplication.class, args);
	}

}
